#!/usr/bin/env python3
from pwn import *
import requests
from katana.units.web import WebUnit
from katana.units import NotApplicable
from hashlib import md5

# Assume that you are in fact the Google crawler.
headers = { 'User-Agent': 'Googlebot/2.1' }

class Unit(WebUnit):

	PRIORITY = 90
	HEADERS = { 'User-Agent': 'Googlebot/2.1' }
	VALID_CODES = [200,204,301,302,307,403]
	NO_RECURSE = True
	ARGUMENTS = [
		{ 'name': 		'dir_list', 
		  'type': 		str, 
		  'default': 	"./tests/directory-list-2.3-medium.txt", 
		  'required': 	False,
		  'help': 		'given word list for bruteforcing web locations'
		},
	]

	def __init__(self, katana, target):
		# Run the parent constructor, to ensure this is a valid URL
		super(Unit, self).__init__(katana, target)
		self.method = requests.head

		try:
			self.method(target.upstream, headers=self.HEADERS)
		except requests.RequestException:
			# I don't know what happens when head isn't supported...
			# I assume that any exception means that but that's probalby
			# dumb...
			self.method = requests.get

		# If this exists, I'll kill myself
		bad_uri = bytes('thisisdefinitelynotreal'+randoms(100), 'utf-8')

		# grab the page that doesn't exist
		r = self.request(katana, bad_uri)

		# This should have failed
		if r.status_code < 400 or r.status_code >= 500:
			raise NotApplicable('did not respond negatively to non-existent file')


	# JOHN: This SHOULD be removed following the new unit argument restructure
	@classmethod
	def add_arguments(cls, katana, parser):
		parser.add_argument('--dir-list', type=str, default='./tests/directory-list-2.3-medium.txt')

	def build_url(self, uri):
		return self.target.upstream + b'/' + uri

	def request(self, katana, uri):
		response = self.method(self.build_url(uri),
				#timeout = katana.config['timeout'],
				headers = self.HEADERS
			)
		return response

	def enumerate(self, katana):
		# Yield all options for the directory listing
		try:
			with open(katana.config['dir_list'], 'rb') as f:
				for line in f:
					line = line.strip()
					# Ignore comments
					if line == b'' or line.startswith(b'#'):
						continue
					yield line
		except OSError:
			# We couldn't open the dictionary... no directory bruteforcing...
			return

	def evaluate(self, katana, uri):

		# Try to grab the URL
		r = self.request(katana, uri)

		# This does not seem to actually exist
		if r.status_code not in self.VALID_CODES:
			return

		log.info('good url found: {0}'.format(self.build_url(uri)))

		# Recurse on the URL if it's valid
		katana.recurse(self, self.build_url(uri))
		katana.add_results(self, self.build_url(uri))
